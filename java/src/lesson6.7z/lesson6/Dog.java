package lesson6;

public class Dog extends Animal{

    public Dog(String name, int run, int swim, int jump, int stop_run, int stop_swim, int stop_jump) {
        super(name, run, swim, jump, stop_run, stop_swim, stop_jump);
    }
}
